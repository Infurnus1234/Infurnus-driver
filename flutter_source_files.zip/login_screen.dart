import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';

import '../../providers/driver_session.dart';
import '../../widgets/google_sign_in_button.dart';
import '../../core/theme.dart';
import 'role_selection_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _identifier = TextEditingController();
  bool _rememberMe = true;
  bool _useEmail = false;
  bool _identifierAttempted = false;
  String? _clientValidationMessage;

  bool get _identifierIsValid {
    final input = _identifier.text.trim();
    if (input.isEmpty) return false;
    if (_useEmail || input.contains('@')) {
      return RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(input);
    }
    return true;
  }

  String? get _emailValidationError {
    if (!_useEmail || !_identifierAttempted) return null;
    final input = _identifier.text.trim();
    if (input.isEmpty) return 'Enter your email address.';
    return RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(input)
        ? null
        : 'Enter a valid email address.';
  }

  String? _loginError(DriverSession session) {
    if (session.error == null) return null;
    if (session.errorCode == 'INVALID_CREDENTIALS') {
      return 'Those sign-in details could not be verified. Check them and retry.';
    }
    return 'We couldn\'t sign you in. Check your connection and try again.';
  }

  @override
  void dispose() {
    _identifier.dispose();
    super.dispose();
  }

  Future<String?> _chooseExistingRole() => showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    builder: (sheetContext) => SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Choose the account to sign in to',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            ProviderRoleCards(
              onChanged: (role) => Navigator.of(sheetContext).pop(role),
            ),
          ],
        ),
      ),
    ),
  );

  void _validateAndSubmit(DriverSession session) async {
    setState(() {
      _identifierAttempted = true;
      _clientValidationMessage = null;
    });
    final rawInput = _identifier.text.trim();

    if (rawInput.isEmpty) {
      setState(() {
        _clientValidationMessage = _useEmail
            ? 'Please enter your email address.'
            : 'Please enter your phone number.';
      });
      return;
    }

    if (_useEmail || rawInput.contains('@')) {
      if (!RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(rawInput)) return;
    } else {
      final digits = rawInput.replaceAll(RegExp(r'\D'), '');
      if (digits.length < 10) {
        setState(
          () => _clientValidationMessage =
              'Please enter a valid 10-digit mobile number.',
        );
        return;
      }
    }

    final fullIdentifier = rawInput;

    session.api.rememberMe = _rememberMe;
    var success = await session.login(fullIdentifier);
    if (!mounted) return;
    if (!success && session.errorCode == 'ACCOUNT_ROLE_REQUIRED') {
      final role = await _chooseExistingRole();
      if (!mounted || role == null) return;
      success = await session.login(fullIdentifier, null, role);
    }
    if (!mounted) return;
    if (success) {
      context.go('/otp');
    }
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<DriverSession>();

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Top Poster Artwork Background (No extra logo widget)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: MediaQuery.of(context).size.height * 0.42,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.asset(
                    'assets/images/login_background.png',
                    fit: BoxFit.cover,
                    alignment: Alignment.topCenter,
                  ),
                ),
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.black.withValues(alpha: 0.15),
                          Colors.black.withValues(alpha: 0.5),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ),
                SafeArea(
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white),
                        onPressed: () {
                          if (context.canPop()) {
                            context.pop();
                          } else {
                            context.go('/welcome');
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Single Clean White Bottom Sheet
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 16,
                    offset: Offset(0, -4),
                  ),
                ],
              ),
              padding: const EdgeInsets.fromLTRB(24, 26, 24, 20),
              child: SafeArea(
                top: false,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Center(
                        child: Text(
                          'Log in or sign up',
                          style: InfurnusTheme.interStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: InfurnusTheme.textDark,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Phone or Email Input Container
                      if (!_useEmail)
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: const Color(0xFFCBD5E1),
                              width: 1.2,
                            ),
                          ),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 15,
                                ),
                                decoration: const BoxDecoration(
                                  border: Border(
                                    right: BorderSide(color: Color(0xFFE2E8F0)),
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    const Text(
                                      '🇮🇳',
                                      style: TextStyle(fontSize: 18),
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      '+91',
                                      style: InfurnusTheme.interStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                        color: InfurnusTheme.textDark,
                                      ),
                                    ),
                                    const SizedBox(width: 4),
                                    const Icon(
                                      Icons.arrow_drop_down,
                                      size: 18,
                                      color: InfurnusTheme.textMuted,
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                child: TextField(
                                  controller: _identifier,
                                  enabled: !session.busy,
                                  keyboardType: TextInputType.phone,
                                  autofillHints: const [
                                    AutofillHints.telephoneNumber,
                                  ],
                                  style: InfurnusTheme.interStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  decoration: const InputDecoration(
                                    hintText: 'Enter Phone Number',
                                    hintStyle: TextStyle(
                                      color: InfurnusTheme.textMuted,
                                    ),
                                    border: InputBorder.none,
                                    enabledBorder: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    contentPadding: EdgeInsets.symmetric(
                                      horizontal: 16,
                                      vertical: 15,
                                    ),
                                  ),
                                  onChanged: (_) => setState(() {
                                    _clientValidationMessage = null;
                                    _identifierAttempted = true;
                                  }),
                                ),
                              ),
                            ],
                          ),
                        )
                      else
                        TextField(
                          controller: _identifier,
                          enabled: !session.busy,
                          keyboardType: TextInputType.emailAddress,
                          autofillHints: const [AutofillHints.email],
                          decoration: InputDecoration(
                            labelText: 'Email Address',
                            prefixIcon: const Icon(Icons.email_outlined),
                            helperText: 'Enter a valid email to continue.',
                            errorText: _emailValidationError,
                          ),
                          onChanged: (_) => setState(() {
                            _clientValidationMessage = null;
                            _identifierAttempted = true;
                          }),
                        ),

                      const SizedBox(height: 12),

                      const Text(
                        'Use your registered phone or email to receive an OTP. Fleet-created Drivers can sign in directly.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 12),
                      ),
                      const SizedBox(height: 12),
                      // Remember my login checkbox
                      Row(
                        children: [
                          SizedBox(
                            height: 24,
                            width: 24,
                            child: Checkbox(
                              value: _rememberMe,
                              activeColor: InfurnusTheme.primaryGreen,
                              onChanged: (v) =>
                                  setState(() => _rememberMe = v ?? true),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Remember my login for faster sign-in',
                              style: InfurnusTheme.interStyle(
                                fontSize: 12,
                                color: InfurnusTheme.textDark,
                              ),
                            ),
                          ),
                          TextButton(
                            onPressed: session.busy
                                ? null
                                : () => setState(() {
                                    _useEmail = !_useEmail;
                                    _identifier.clear();
                                    _identifierAttempted = false;
                                    _clientValidationMessage = null;
                                  }),
                            child: Text(
                              _useEmail ? 'Use Phone' : 'Use Email',
                              style: InfurnusTheme.interStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: InfurnusTheme.primaryGreen,
                              ),
                            ),
                          ),
                        ],
                      ),

                      // Error display
                      if (_clientValidationMessage != null ||
                          _loginError(session) != null) ...[
                        Container(
                          margin: const EdgeInsets.symmetric(vertical: 8),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFEF2F2),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: const Color(0xFFFCA5A5)),
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.error_outline,
                                size: 18,
                                color: InfurnusTheme.dangerRed,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  _clientValidationMessage ??
                                      _loginError(session)!,
                                  style: GoogleFonts.inter(
                                    color: InfurnusTheme.dangerRed,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],

                      const SizedBox(height: 12),

                      // Primary Continue Button
                      ElevatedButton(
                        onPressed:
                            session.busy || (_useEmail && !_identifierIsValid)
                            ? null
                            : () => _validateAndSubmit(session),
                        child: session.busy
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Continue',
                                    style: InfurnusTheme.interStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  const Icon(Icons.arrow_forward, size: 18),
                                ],
                              ),
                      ),

                      const SizedBox(height: 16),

                      const SizedBox(height: 14),
                      const Divider(color: Color(0xFFE2E8F0)),
                      const SizedBox(height: 10),

                      // Google Sign In & Create Account
                      GoogleSignInButton(
                        label: 'Continue with Google',
                        enabled: !session.busy,
                        onIdToken: (token) async {
                          session.api.rememberMe = _rememberMe;
                          var ok = await session.authenticateGoogle(
                            token,
                            signup: true,
                          );
                          if (mounted &&
                              !ok &&
                              session.errorCode == 'ACCOUNT_ROLE_REQUIRED') {
                            final role = await _chooseExistingRole();
                            if (!mounted || role == null) return;
                            ok = await session.authenticateGoogle(
                              token,
                              signup: true,
                              accountRole: role,
                            );
                          }
                          if (context.mounted && ok && session.authenticated) {
                            context.go(session.landingPath);
                          }
                        },
                      ),

                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: session.busy
                            ? null
                            : () => context.go('/role-selection'),
                        child: Text(
                          'Create an account with email or phone',
                          style: InfurnusTheme.interStyle(
                            fontWeight: FontWeight.bold,
                            color: InfurnusTheme.textDark,
                            fontSize: 13,
                          ),
                        ),
                      ),

                      const SizedBox(height: 10),

                      // Terms & Privacy footer
                      Text(
                        'By continuing, you agree to our Terms of Service, Privacy Policy & Content Policy',
                        textAlign: TextAlign.center,
                        style: InfurnusTheme.interStyle(
                          fontSize: 10.5,
                          color: InfurnusTheme.textMuted,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          if (session.restorationNeedsRetry)
            MaterialBanner(
              content: const Text(
                'Your saved session could not be restored. Retry when connected or sign in again.',
              ),
              actions: [
                TextButton(
                  onPressed: session.busy ? null : session.restore,
                  child: const Text('Retry session'),
                ),
              ],
            ),
        ],
      ),
    );
  }
}
